# Data availability and provenance

The original 3,000-row campaign CSV is **not included** in this archive. The script requires the source CSV with the columns used in the audit. The original dataset SHA-256 is recorded in `results/manifest.json`; compare it before claiming an exact rerun.

The supplied package includes row-level holdout and out-of-fold predictions, split membership, frozen embeddings and other derived results. These may expose information about original records or underlying source material. **Review source permissions, confidentiality, consent, contractual restrictions and the risk of re-identification before making this repository public.** Inclusion here does not establish redistribution rights.

The original newer-pipeline helper modules, historical run logs, final historical feature list and original local model weights were not provided. The corrected audit is not a reproduction of that historical implementation.

The supplied holdout was previously examined. It must not be described as a fresh confirmatory test. Financial-variable provenance, timing and `Synthetic_Entry_Flag` meaning remain unresolved.

If the data cannot be released, replace this document with a specific justified access procedure approved by the data owner and journal. Do not fabricate a public or synthetic substitute and call it the research dataset.
