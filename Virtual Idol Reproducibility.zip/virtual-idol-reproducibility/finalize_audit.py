from pathlib import Path
import json,hashlib,shutil,zipfile
import pandas as pd,numpy as np
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error

root=Path(__file__).resolve().parent;out=root/'results'
m=pd.read_csv(out/'metrics.csv');h=pd.read_csv(out/'holdout_predictions.csv')
o=pd.read_csv(out/'oof_predictions.csv');cv=pd.read_csv(out/'cv_metrics.csv')
mem=pd.read_csv(out/'cv_membership.csv');s=pd.read_csv(out/'split_assignment.csv')
train=set(s.loc[s.split=='development','row_index']);test=set(s.loc[s.split=='holdout','row_index'])
assert len(train)==2400 and len(test)==600 and train.isdisjoint(test)
assert set(h.row_index)==test and set(o.row_index)==train
assert h.row_index.is_unique and o.row_index.is_unique
for f in range(1,6):
 sub=mem[mem.fold==f]
 a,b,c=[set(sub.loc[sub.role==role,'row_index']) for role in ['inner_fit','inner_stop','outer_validation']]
 assert not a&b and not a&c and not b&c
 assert a|b|c==train and not set(sub.row_index)&test
for row in m.to_dict('records'):
 n=row['model'];p=h[n].to_numpy()
 assert np.isfinite(p).all() and np.isfinite(o[n]).all()
 assert abs(r2_score(h.actual,p)-row['r2'])<1e-12
 assert abs(mean_absolute_error(h.actual,p)-row['mae'])<1e-8
 assert abs(np.sqrt(mean_squared_error(h.actual,p))-row['rmse'])<1e-8
 assert abs(r2_score(o.actual,o[n])-row['oof_r2'])<1e-12
 fc=cv[cv.model==n];assert len(fc)==5
 assert abs(fc.r2.mean()-row['cv_mean_r2'])<1e-12
 if n!='mean_baseline':assert int(np.rint(np.median(fc.selected_iterations)))==row['final_iterations']
manifest=json.loads((out/'manifest.json').read_text())
status=json.loads((root/'embedding_status.json').read_text())
# Preserve executed local-model argument and annotate its separately recorded source.
manifest['embedding']['download_provenance']=status
manifest['embedding']['local_model_file_hashes']={
 str(p.relative_to(root/'model_cache')):hashlib.sha256(p.read_bytes()).hexdigest()
 for p in (root/'model_cache').rglob('*') if p.is_file()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
for n in ['nonfinancial_structured','nonfinancial_plus_sbert','restricted_structured','restricted_plus_sbert']:
 cols=set(manifest['feature_sets'][n]['structured'])
 assert not cols&set(manifest['financial_exclusions'])
 assert not cols&set(['Ad_Campaign_Cost_USD']+manifest['metadata_exclusions'])
emb=np.load(out/'frozen_embeddings.npz')['embeddings'];assert emb.shape==(3000,1152)
assert hashlib.sha256(emb.tobytes()).hexdigest()==manifest['embedding']['sha256']
imp=pd.read_csv(out/'all_structured_importance.csv')
share=float(imp.loc[imp.feature=='num__Total_Advertising_Cost_USD','gain'].sum()/imp.gain.sum())
checks={'holdout_metrics_recomputed':True,'oof_r2_recomputed':True,'five_fold_means_verified':True,
 'all_cv_role_sets_disjoint':True,'holdout_excluded_from_all_cv_stages':True,
 'median_iteration_selection_verified':True,'feature_exclusion_invariants_passed':True,
 'embedding_matrix_hash_verified':True,'total_cost_gain_share':share}
(out/'verification.json').write_text(json.dumps(checks,indent=2))
for name in ['proposed_guard','supplied_evidence']:
 shutil.copytree(root.parent/'benchmark'/name,root/name,dirs_exist_ok=True)
shutil.copy2(root.parent/'benchmark/guard_execution_check.json',root/'guard_execution_check.json')
lines=['# Virtual-idol pricing: corrected frozen-SBERT–LightGBM comparison','',
'Completed 27 October 2026. This extends the earlier Extra Trees/TF-IDF diagnostic with actual frozen MiniLM embeddings and LightGBM. It is an independent corrected comparison, not reproduction of the historical run. Original files and manuscript were not edited.','',
'## Executed design','',
'The original 3,000-row CSV was retained without synthetic-flag filtering. The same development/holdout membership as the prior audit was used (2,400/600). This already examined holdout is exploratory, not a fresh confirmatory lockbox. Data hashes, versions, feature names, model parameters and split membership are recorded.','',
'Frozen sentence-transformers/all-MiniLM-L6-v2 was downloaded at revision '+status['revision']+'. Each of three text fields supplies 384 dimensions (1,152 total). Thirty unique strings were encoded without fitting on campaign outcomes. These are sentence embeddings, not supervised sentiment scores or fine-tuned BERT.','',
'Seven specifications were declared before the run. Within each outer fold, an inner 80/20 split selects iterations by early stopping. A model refit on the entire outer training fold is scored on untouched outer validation rows. The rounded median of five selected iteration counts controls the final development-data refit. No hyperparameter grid search or holdout-based selection was performed. Encoders are training-fitted at every stage. Numerical percentage units are retained from the raw CSV; the unavailable original cleaning helper is not reproduced.','',
'The nonfinancial sensitivity excludes 14 finance-related names plus ID/source/synthetic-flag/tier metadata. Restricted models exclude nine further timing-uncertain fields. This is conservative: historical financial measurements might be valid if independently documented; every retained predictor also still requires timing verification.','',
'## Results','',
'| Specification | Holdout R² | MAE (USD) | RMSE (USD) | Mean CV R² | Final trees |',
'|---|---:|---:|---:|---:|---:|']
for r in m.to_dict('records'):
 lines.append(f"| {r['model']} | {r['r2']:.6f} | {r['mae']:,.2f} | {r['rmse']:,.2f} | {r['cv_mean_r2']:.6f} | {r['final_iterations']} |")
lines += ['',
'## Findings','',
'1. The nonfinancial SBERT model has holdout R² = 0.000566 and mean CV R² = -0.001155. Its MAE is USD 12,306, versus USD 12,315 for the training-mean baseline. This is practically negligible improvement under this specification. The restricted SBERT model is similarly near baseline.','',
'2. Adding SBERT to nonfinancial structured features changes holdout R² by +0.000416, with paired conditional bootstrap 95% interval [-0.011956, 0.012658]. For restricted features the change is -0.000237, with interval [-0.003887, 0.003328]. Both intervals include zero. They condition on this fitted model and holdout and do not cover full training or market-population uncertainty.','',
'3. Total cost alone reaches holdout R² = 0.960941; all structured predictors reach 0.958084. Total advertising cost contributes '+f'{share:.2%}'+' of gain importance in the latter model. This is descriptive, not a causal attribution or a linkage to the historical run.','',
'4. The uploaded guard with an empty rules file retains financial predictors. Its feature module supplies no later financial filter. The saved historical R² = 0.957659 is numerically similar to the financially unrestricted diagnostics, but that does not establish which historical source version produced it. Exact feature names, logs, helper modules and original local MiniLM weights remain unavailable.','',
'5. Both SBERT models select only one final tree from development data. This is consistent with negligible useful signal under the tested specifications, not proof that all possible models lack signal. Random row splits do not establish unseen-idol, source-held-out or future-period validity.','',
'## Consequences for the paper','',
'These results do not support high predictive performance as evidence of sentiment-driven campaign valuation after financial-field exclusion. Stronger prose cannot repair that empirical gap. The current finding concerns reliance on closely related financial measurements, not a validated substantive mechanism about sentiment or demand. It does not establish fabrication: quantitative source traceability and synthetic-flag meaning remain separate unresolved questions.','',
'No causal effect, demand elasticity, optimal pricing, calibrated uncertainty or profit-at-risk claim is validated by these tests. No manuscript rewrite recasts the near-null prediction result as a successful pricing model.','',
'## Completed and remaining work','',
'The matched structured-only versus actual frozen-SBERT–LightGBM diagnostic is complete. All seven holdout R²/MAE/RMSE sets and out-of-fold R² values were independently recomputed. Five-fold means, split-role separation, development-only selection counts, exclusions and embedding hashes passed verification.','',
'Next required evidence is source-to-value documentation and timing: identify campaign costs and predictor values that were directly observed, their campaign/idol identities and dates, and the meaning of Synthetic_Entry_Flag. These determine the defensible prospective predictor set and manuscript framing. A historical-run audit additionally requires the saved final feature list and run log. More repeated model fitting cannot supply those records.','',
'The earlier ZIP was checked: none of the six newer required helper-module paths is present. The independent runner resolves the immediate execution blocker for this comparison but cannot recover the historical implementation.','',
'## Package contents and use','',
'See README.md for the rerun command. Source data and pretrained weights are excluded; public revision and file hashes are included together with the computed embeddings, OOF/holdout predictions, metrics, splits and fitted tree text files. Tree text files alone are not full deployment bundles because encoders are rebuilt by the runner.','',
'proposed_guard/ contains the separately tested replacement pair. Both files must be adopted together: broad financial regex rules in the old guard would remove the active target. The candidate rejects empty exclusions and protects the active target. It has not been installed in the original project. Supplied source files are preserved under supplied_evidence/.']
(root/'AUDIT_REPORT.md').write_text('\n'.join(lines)+'\n')
archive=root.parent/'Virtual_Idol_SBERT_LightGBM_Verified_27Oct2026.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and 'model_cache' not in p.parts and '__pycache__' not in p.parts:
   z.write(p,'Virtual_Idol_SBERT_LightGBM_Audit/'+str(p.relative_to(root)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'checks':checks,'archive':str(archive),'bytes':archive.stat().st_size},indent=2))
