"""Corrected independent LightGBM comparison, not historical run reproduction.
Run with --data INPUT.csv --previous-splits split_assignment.csv --out results.
Optional --sbert-model local/path or Hugging Face model ID, --revision COMMIT.
Frozen embeddings may be computed before splitting: no corpus/target fitting occurs.
"""
import argparse, hashlib, importlib.metadata, json, platform, re
from pathlib import Path
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split,KFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error

TARGET='Ad_Campaign_Cost_USD'
TEXT=['Sample_Review','Positive_Comment','Negative_Comment']
META=['Idol_ID','Reference_Source','Synthetic_Entry_Flag','Pricing_Tier_Label']
PATTERN=r'cost|price|pricing|revenue|roi|elasticity|sales|ad_spend'
TIMING=['Click_Through_Rate (%)','Conversion_Rate (%)','Reach','Watch_Time_Minutes',
 'Campaign_Success_Rate (%)','Event_Boost_Flag','Platform_Algorithm_Boost_Score',
 'Paid_Boost_Used','Online_Mentions_Count']
PARAMS=dict(n_estimators=1000,learning_rate=.03,num_leaves=63,subsample=.8,
 colsample_bytree=.8,reg_alpha=0.,reg_lambda=0.,min_child_samples=20,
 random_state=42,n_jobs=2,objective='regression',verbosity=-1)

def metrics(y,p):
 y=np.asarray(y);p=np.asarray(p)
 return dict(r2=float(r2_score(y,p)),mae=float(mean_absolute_error(y,p)),
  rmse=float(np.sqrt(mean_squared_error(y,p))),
  mape_percent=float(np.mean(np.abs((y-p)/np.maximum(np.abs(y),1e-12)))*100))

def design(d,cols,fit_idx,other_idx,embedding=None):
 num=[c for c in cols if pd.api.types.is_numeric_dtype(d[c])]
 cat=[c for c in cols if c not in num]
 t=[]
 if num:t.append(('num',SimpleImputer(strategy='median'),num))
 if cat:t.append(('cat',Pipeline([('fill',SimpleImputer(strategy='most_frequent')),
  ('onehot',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),cat))
 encoder=ColumnTransformer(t,sparse_threshold=0)
 a=encoder.fit_transform(d.iloc[fit_idx]).astype(np.float32)
 b=encoder.transform(d.iloc[other_idx]).astype(np.float32)
 names=list(map(str,encoder.get_feature_names_out()))
 if embedding is not None:
  a=np.column_stack([a,embedding[fit_idx]]);b=np.column_stack([b,embedding[other_idx]])
  names += [f'sbert_{field}_{j:03}' for field in TEXT for j in range(embedding.shape[1]//len(TEXT))]
 return a,b,names

def model(iterations=None):
 p=PARAMS.copy()
 if iterations is not None:p['n_estimators']=int(iterations)
 return lgb.LGBMRegressor(**p)

def run(a):
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 d=pd.read_csv(a.data);y=pd.to_numeric(d[TARGET],errors='raise').to_numpy(float)
 if not np.isfinite(y).all():raise ValueError('Nonfinite target')
 s=pd.read_csv(a.previous_splits).sort_values('row_index')
 assert len(s)==len(d) and np.array_equal(s.row_index,np.arange(len(d)))
 assert np.array_equal(s.Idol_ID,d.Idol_ID)
 train=s.loc[s.split=='development','row_index'].to_numpy()
 test=s.loc[s.split=='holdout','row_index'].to_numpy()
 # Canonical ordering from the supplied split CSV; identical membership to prior audit.
 folds=list(KFold(5,shuffle=True,random_state=42).split(train))
 emb=None;embinfo={'available':False,'reason':'No SBERT model supplied'}
 if a.sbert_model:
  import torch
  from sentence_transformers import SentenceTransformer
  torch.set_num_threads(2)
  kwargs={'device':'cpu'}
  if a.revision:kwargs['revision']=a.revision
  enc=SentenceTransformer(a.sbert_model,**kwargs);enc.eval()
  values=sorted(set(d[TEXT].fillna('').to_numpy().ravel()))
  vectors=enc.encode(values,batch_size=64,normalize_embeddings=False,show_progress_bar=False)
  lookup={v:vectors[i] for i,v in enumerate(values)}
  emb=np.column_stack([np.stack([lookup[v] for v in d[c].fillna('')]) for c in TEXT]).astype(np.float32)
  np.savez_compressed(out/'frozen_embeddings.npz',embeddings=emb)
  embinfo={'available':True,'model':a.sbert_model,'revision':a.revision,
   'dimensions':emb.shape[1],'unique_texts':len(values),'frozen':True,
   'normalization':False,'sha256':hashlib.sha256(emb.tobytes()).hexdigest()}
  print('EMBEDDINGS',json.dumps(embinfo),flush=True)
 base=[c for c in d if c not in [TARGET]+TEXT+META]
 fin=[c for c in base if re.search(PATTERN,c,re.I)]
 nf=[c for c in base if c not in fin];restricted=[c for c in nf if c not in TIMING]
 specs=[('mean_baseline',[],False),('total_cost_only',['Total_Advertising_Cost_USD'],False),
  ('all_structured',base,False),('nonfinancial_structured',nf,False)]
 if emb is not None:specs.append(('nonfinancial_plus_sbert',nf,True))
 specs.append(('restricted_structured',restricted,False))
 if emb is not None:specs.append(('restricted_plus_sbert',restricted,True))
 manifest={'input_sha256':hashlib.sha256(Path(a.data).read_bytes()).hexdigest(),
 'split_sha256':hashlib.sha256(Path(a.previous_splits).read_bytes()).hexdigest(),
 'rows':len(d),'development':len(train),'holdout':len(test),'target':TARGET,
 'params':PARAMS,'early_stopping_rounds':100,'embedding':embinfo,
 'selection':'Each outer-training subset has an 80/20 inner fit/early-stop split. Refit on outer-training rows; score only untouched outer validation. Final iteration count is rounded median of five selected counts; refit on all development rows. No holdout selection.',
 'financial_exclusions':fin,'metadata_exclusions':META,'timing_exclusions':TIMING,
 'feature_sets':{n:{'structured':c,'sbert':t} for n,c,t in specs},
 'versions':{'python':platform.python_version(),**{p:importlib.metadata.version(p) for p in ['numpy','pandas','scikit-learn','lightgbm']}}}
 if emb is not None:
  manifest['versions'].update({p:importlib.metadata.version(p) for p in ['torch','sentence-transformers','transformers']})
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
 s.to_csv(out/'split_assignment.csv',index=False)
 held=pd.DataFrame({'row_index':test,'Idol_ID':d.Idol_ID.iloc[test].to_numpy(),'actual':y[test]})
 oof=pd.DataFrame({'row_index':train,'Idol_ID':d.Idol_ID.iloc[train].to_numpy(),'actual':y[train]})
 foldrows=[];results=[];members=[];features={}
 for fold,(tr,va) in enumerate(folds,1):
  inner_fit,inner_stop=train_test_split(train[tr],test_size=.2,random_state=4200+fold)
  for role,ids in [('inner_fit',inner_fit),('inner_stop',inner_stop),('outer_validation',train[va])]:
   members.extend({'fold':fold,'row_index':int(i),'role':role} for i in ids)
 pd.DataFrame(members).to_csv(out/'cv_membership.csv',index=False)
 for name,cols,use_emb in specs:
  e=emb if use_emb else None;pred_oof=np.full(len(train),np.nan);selected=[]
  for fold,(tr,va) in enumerate(folds,1):
   outer_train=train[tr];outer_val=train[va]
   if name=='mean_baseline':
    p=np.full(len(va),np.mean(y[outer_train]));n=0
   else:
    inner_fit,inner_stop=train_test_split(outer_train,test_size=.2,random_state=4200+fold)
    x,z,_=design(d,cols,inner_fit,inner_stop,e)
    choose=model();choose.fit(x,y[inner_fit],eval_set=[(z,y[inner_stop])],eval_metric='rmse',
     callbacks=[lgb.early_stopping(100,verbose=False)])
    n=int(choose.best_iteration_ or PARAMS['n_estimators'])
    x,z,_=design(d,cols,outer_train,outer_val,e)
    fitted=model(n);fitted.fit(x,y[outer_train]);p=fitted.predict(z)
   selected.append(n);pred_oof[va]=p
   foldrows.append({'model':name,'fold':fold,'selected_iterations':n,**metrics(y[outer_val],p)})
  if name=='mean_baseline':
   p=np.full(len(test),np.mean(y[train]));final_n=0
  else:
   final_n=max(1,int(np.rint(np.median(selected))))
   x,z,names=design(d,cols,train,test,e);fitted=model(final_n);fitted.fit(x,y[train]);p=fitted.predict(z)
   features[name]=names
   pd.DataFrame({'feature':names,'gain':fitted.booster_.feature_importance(importance_type='gain')}).sort_values('gain',ascending=False).to_csv(out/(name+'_importance.csv'),index=False)
   fitted.booster_.save_model(str(out/(name+'_model.txt')))
  assert np.isfinite(pred_oof).all()
  held[name]=p;oof[name]=pred_oof
  row={'model':name,'final_iterations':final_n,'structured_features':len(cols),'sbert':use_emb,**metrics(y[test],p)}
  fr=[r for r in foldrows if r['model']==name]
  row.update({'cv_mean_r2':float(np.mean([r['r2'] for r in fr])),
   'cv_sd_r2':float(np.std([r['r2'] for r in fr],ddof=1)),
   'oof_r2':float(r2_score(y[train],pred_oof))})
  results.append(row)
  pd.DataFrame(results).to_csv(out/'metrics.csv',index=False)
  held.to_csv(out/'holdout_predictions.csv',index=False)
  oof.to_csv(out/'oof_predictions.csv',index=False)
  pd.DataFrame(foldrows).to_csv(out/'cv_metrics.csv',index=False)
  (out/'encoded_feature_names.json').write_text(json.dumps(features,indent=2))
  print('RESULT',json.dumps(row),flush=True)
 increments=[]
 if emb is not None:
  for root in ['nonfinancial','restricted']:
   b=held[root+'_structured'].to_numpy();t=held[root+'_plus_sbert'].to_numpy();truth=held.actual.to_numpy()
   rng=np.random.default_rng(20261027);delta=[]
   for ids in rng.integers(0,len(test),size=(1000,len(test))):
    delta.append(r2_score(truth[ids],t[ids])-r2_score(truth[ids],b[ids]))
   increments.append({'comparison':root,'holdout_delta_r2':float(r2_score(truth,t)-r2_score(truth,b)),
    'conditional_ci95':list(map(float,np.quantile(delta,[.025,.975]))),
    'oof_delta_r2':float(r2_score(oof.actual,oof[root+'_plus_sbert'])-r2_score(oof.actual,oof[root+'_structured']))})
 (out/'sbert_increment.json').write_text(json.dumps(increments,indent=2))
 print('INCREMENTS',json.dumps(increments),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--previous-splits',required=True)
 p.add_argument('--out',default='results');p.add_argument('--sbert-model');p.add_argument('--revision')
 run(p.parse_args())
