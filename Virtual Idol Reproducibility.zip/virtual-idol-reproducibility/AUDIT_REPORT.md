# Virtual-idol pricing: corrected frozen-SBERT–LightGBM comparison

Completed 27 October 2026. This extends the earlier Extra Trees/TF-IDF diagnostic with actual frozen MiniLM embeddings and LightGBM. It is an independent corrected comparison, not reproduction of the historical run. Original files and manuscript were not edited.

## Executed design

The original 3,000-row CSV was retained without synthetic-flag filtering. The same development/holdout membership as the prior audit was used (2,400/600). This already examined holdout is exploratory, not a fresh confirmatory lockbox. Data hashes, versions, feature names, model parameters and split membership are recorded.

Frozen sentence-transformers/all-MiniLM-L6-v2 was downloaded at revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41. Each of three text fields supplies 384 dimensions (1,152 total). Thirty unique strings were encoded without fitting on campaign outcomes. These are sentence embeddings, not supervised sentiment scores or fine-tuned BERT.

Seven specifications were declared before the run. Within each outer fold, an inner 80/20 split selects iterations by early stopping. A model refit on the entire outer training fold is scored on untouched outer validation rows. The rounded median of five selected iteration counts controls the final development-data refit. No hyperparameter grid search or holdout-based selection was performed. Encoders are training-fitted at every stage. Numerical percentage units are retained from the raw CSV; the unavailable original cleaning helper is not reproduced.

The nonfinancial sensitivity excludes 14 finance-related names plus ID/source/synthetic-flag/tier metadata. Restricted models exclude nine further timing-uncertain fields. This is conservative: historical financial measurements might be valid if independently documented; every retained predictor also still requires timing verification.

## Results

| Specification | Holdout R² | MAE (USD) | RMSE (USD) | Mean CV R² | Final trees |
|---|---:|---:|---:|---:|---:|
| mean_baseline | -0.000043 | 12,314.64 | 14,190.69 | -0.000758 | 0 |
| total_cost_only | 0.960941 | 2,366.83 | 2,804.51 | 0.961040 | 140 |
| all_structured | 0.958084 | 2,452.95 | 2,905.27 | 0.958381 | 156 |
| nonfinancial_structured | 0.000150 | 12,295.69 | 14,189.32 | -0.013561 | 16 |
| nonfinancial_plus_sbert | 0.000566 | 12,306.13 | 14,186.37 | -0.001155 | 1 |
| restricted_structured | 0.001043 | 12,304.53 | 14,182.98 | -0.004189 | 2 |
| restricted_plus_sbert | 0.000806 | 12,304.11 | 14,184.67 | -0.001976 | 1 |

## Findings

1. The nonfinancial SBERT model has holdout R² = 0.000566 and mean CV R² = -0.001155. Its MAE is USD 12,306, versus USD 12,315 for the training-mean baseline. This is practically negligible improvement under this specification. The restricted SBERT model is similarly near baseline.

2. Adding SBERT to nonfinancial structured features changes holdout R² by +0.000416, with paired conditional bootstrap 95% interval [-0.011956, 0.012658]. For restricted features the change is -0.000237, with interval [-0.003887, 0.003328]. Both intervals include zero. They condition on this fitted model and holdout and do not cover full training or market-population uncertainty.

3. Total cost alone reaches holdout R² = 0.960941; all structured predictors reach 0.958084. Total advertising cost contributes 93.92% of gain importance in the latter model. This is descriptive, not a causal attribution or a linkage to the historical run.

4. The uploaded guard with an empty rules file retains financial predictors. Its feature module supplies no later financial filter. The saved historical R² = 0.957659 is numerically similar to the financially unrestricted diagnostics, but that does not establish which historical source version produced it. Exact feature names, logs, helper modules and original local MiniLM weights remain unavailable.

5. Both SBERT models select only one final tree from development data. This is consistent with negligible useful signal under the tested specifications, not proof that all possible models lack signal. Random row splits do not establish unseen-idol, source-held-out or future-period validity.

## Consequences for the paper

These results do not support high predictive performance as evidence of sentiment-driven campaign valuation after financial-field exclusion. Stronger prose cannot repair that empirical gap. The current finding concerns reliance on closely related financial measurements, not a validated substantive mechanism about sentiment or demand. It does not establish fabrication: quantitative source traceability and synthetic-flag meaning remain separate unresolved questions.

No causal effect, demand elasticity, optimal pricing, calibrated uncertainty or profit-at-risk claim is validated by these tests. No manuscript rewrite recasts the near-null prediction result as a successful pricing model.

## Completed and remaining work

The matched structured-only versus actual frozen-SBERT–LightGBM diagnostic is complete. All seven holdout R²/MAE/RMSE sets and out-of-fold R² values were independently recomputed. Five-fold means, split-role separation, development-only selection counts, exclusions and embedding hashes passed verification.

Next required evidence is source-to-value documentation and timing: identify campaign costs and predictor values that were directly observed, their campaign/idol identities and dates, and the meaning of Synthetic_Entry_Flag. These determine the defensible prospective predictor set and manuscript framing. A historical-run audit additionally requires the saved final feature list and run log. More repeated model fitting cannot supply those records.

The earlier ZIP was checked: none of the six newer required helper-module paths is present. The independent runner resolves the immediate execution blocker for this comparison but cannot recover the historical implementation.

## Package contents and use

See README.md for the rerun command. Source data and pretrained weights are excluded; public revision and file hashes are included together with the computed embeddings, OOF/holdout predictions, metrics, splits and fitted tree text files. Tree text files alone are not full deployment bundles because encoders are rebuilt by the runner.

proposed_guard/ contains the separately tested replacement pair. Both files must be adopted together: broad financial regex rules in the old guard would remove the active target. The candidate rejects empty exclusions and protects the active target. It has not been installed in the original project. Supplied source files are preserved under supplied_evidence/.
