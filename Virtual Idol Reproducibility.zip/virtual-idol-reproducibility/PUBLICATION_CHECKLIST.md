# Publication gate (not yet cleared)

- [x] Preserve corrected diagnostic scripts and saved outputs from supplied archive.
- [x] Preserve original audit report, version manifest, split membership and provenance caveats.
- [ ] Confirm code ownership and license.
- [ ] Review row-level predictions, split membership, embeddings and model files for permitted public disclosure.
- [ ] Supply authorized source CSV or documented restricted-access process.
- [ ] Run end-to-end reproduction in a clean environment with the original CSV.
- [ ] Independently reconcile current manuscript tables with this corrected audit.
- [ ] Establish source provenance and measurement timing for predictors.
- [ ] Resolve synthetic-flag meaning and historical-run provenance.
