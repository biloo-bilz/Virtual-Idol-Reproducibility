"""
Leakage guard for the Virtual Idol Pricing project.

Removes columns that would leak the target (price/cost/revenue, or the other target),
plus any explicitly listed drops in config/feature_guard.yaml and config.data.drop_columns.
"""

from __future__ import annotations

import re
import yaml
import pandas as pd
from typing import Dict, Any


def _load_guard_rules(guard_yaml_path: str) -> Dict[str, Any]:
    with open(guard_yaml_path, "r", encoding="utf-8") as f:
        rules = yaml.safe_load(f) or {}
    rules.setdefault("regex_drops", [])
    rules.setdefault("explicit_drops", [])
    return rules


def _regex_drop_columns(columns, patterns):
    """Return set of columns that match ANY of the regex patterns (case-insensitive)."""
    drops = set()
    compiled = [re.compile(pat, flags=re.IGNORECASE) for pat in (patterns or [])]
    for col in columns:
        for rx in compiled:
            if rx.search(col):
                drops.add(col)
                break
    return drops


def apply_leak_guard(df: pd.DataFrame, cfg: Dict[str, Any], task: str) -> pd.DataFrame:
    """
    Drop leakage-prone columns.

    Parameters
    ----------
    df : DataFrame
        Input dataframe.
    cfg : dict
        Loaded configuration dictionary.
    task : str
        Either "regression" or "classification". Ensures we drop the *other* target.

    Returns
    -------
    DataFrame
        Dataframe with leakage-prone columns removed.
    """
    if task not in {"regression", "classification"}:
        raise ValueError("task must be 'regression' or 'classification'")

    out = df.copy()
    cols = set(out.columns)

    # Load guard rules from YAML
    guard_path = cfg["paths"]["leakage_guard_yaml"]
    rules = _load_guard_rules(guard_path)
    regex_patterns = rules.get("regex_drops", [])
    explicit_drops = set(rules.get("explicit_drops", []))

    # Always drop the opposite task's target
    reg_tgt = cfg["data"]["target_regression"]
    cls_tgt = cfg["data"]["target_classification"]
    if task == "regression":
        explicit_drops.add(cls_tgt)
    else:  # classification task
        explicit_drops.add(reg_tgt)

    # Optional force-drops from config.data.drop_columns
    force_drops = set(cfg["data"].get("drop_columns", []))

    # Apply regex-based drops
    regex_drops = _regex_drop_columns(cols, regex_patterns)

    # Build final drop set
    to_drop = (explicit_drops | force_drops | regex_drops) & cols
    if to_drop:
        out = out.drop(columns=sorted(to_drop))

    return out
