"""Candidate guard: fail on empty rules; preserve the active supervised target."""
from __future__ import annotations
import re
from pathlib import Path
import yaml

def apply_leak_guard(df, cfg, task):
    if task not in {'regression', 'classification'}:
        raise ValueError('task must be regression or classification')
    p = Path(cfg['paths']['leakage_guard_yaml'])
    rules = yaml.safe_load(p.read_text(encoding='utf-8'))
    if not isinstance(rules, dict):
        raise ValueError('Leakage guard must be a nonempty YAML mapping')
    patterns = rules.get('regex_drops', []) or []
    explicit = set(rules.get('explicit_drops', []) or [])
    forced = set(cfg['data'].get('drop_columns', []) or [])
    if not patterns and not explicit and not forced:
        raise ValueError('No predictor exclusion rules configured; refusing to train')
    reg = cfg['data']['target_regression']
    cls = cfg['data']['target_classification']
    target, opposite = (reg, cls) if task == 'regression' else (cls, reg)
    if target not in df:
        raise KeyError('Active target is absent: ' + target)
    if target in explicit or target in forced:
        raise ValueError('Active target must not appear in explicit drop lists')
    compiled = [re.compile(pattern, re.I) for pattern in patterns]
    matched = {c for c in df if c != target and any(rx.search(c) for rx in compiled)}
    drops = (explicit | forced | matched | {opposite}) & set(df.columns)
    return df.drop(columns=sorted(drops)).copy()
