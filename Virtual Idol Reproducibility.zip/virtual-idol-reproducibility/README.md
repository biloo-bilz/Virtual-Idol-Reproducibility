# Corrected frozen-SBERT / LightGBM diagnostic

This is a new matched comparison, not reproduction of the author's historical run.
The original newer-pipeline helper modules and local model weights were not supplied.
The earlier ZIP was checked and does not contain those newer helper modules.

The model is frozen sentence-transformers/all-MiniLM-L6-v2, pinned to the revision
recorded in embedding_status.json. Three text fields are embedded separately and
concatenated (3 × 384 dimensions). No encoder fine-tuning or sentiment supervision
is performed. Encoding fixed text before splitting uses no campaign target values.
The local cache is not included; the public model can be downloaded again.

Example rerun (use the exact revision from embedding_status.json):

```text
python run_lightgbm_audit.py --data INPUT.csv --previous-splits split_assignment.csv --out results --sbert-model sentence-transformers/all-MiniLM-L6-v2 --revision REVISION
```

Dependencies: numpy, pandas, scikit-learn, lightgbm, torch, sentence-transformers.
Exact installed versions are recorded in results/manifest.json. For CPU machines,
install the CPU build of torch to avoid downloading GPU runtime dependencies.

The original 3,000 observations are retained. The benchmark reuses the prior audit's
development/holdout membership (2,400/600). The existing holdout has already been
examined during diagnostics and must not be described as a new confirmatory lockbox.
All comparisons are exploratory. Cross-validation training and validation subsets
are recorded in cv_membership.csv. Ordering within development is canonical row order;
the prior Extra Trees run used the returned split order, so its CV folds are not
identical even though development and holdout membership are identical.

For each outer fold, iterations are selected using an inner 80/20 split of that
fold's training rows. The model is then refitted on all outer-training rows and
scored on the untouched outer validation rows. Encoders are refitted at each
training stage and ignore unseen categories. The rounded median of the five selected
iteration counts controls the final development-data refit. No hyperparameter grid
search is performed. This is development-only selection, not a claim to exhaustive
nested tuning. Original main model hyperparameters are retained, with n_jobs=2
and an explicit squared-error objective. The uploaded subsample=0.8 is retained;
bagging frequency is not added, so no claim is made that row subsampling is active.

Total-cost and all-structured runs are contamination-sensitive positive controls.
The nonfinancial specification conservatively excludes finance-related names and
metadata; the restricted specification additionally excludes nine timing-uncertain
fields. This does not establish that every financial field is invalid or that every
remaining field was measured before the predicted campaign. Provenance and timing
still require source evidence. No causal, demand-elasticity or pricing-optimality
interpretation is justified by these prediction tests.

Saved metrics, out-of-fold predictions, holdout predictions, split membership,
feature names, gain importance, fitted tree text files, frozen embeddings and audit
checks permit independent examination. The tree text files alone are not deployment
bundles: categorical encoder state is not serialized; rerun the script to rebuild it.
Bootstrap intervals for text increments condition on this sample, split and fitted
models; they do not estimate uncertainty across sources, idols or future markets.

The earlier verified package's proposed_guard/ directory is included as a separately
tested candidate guard pair. It was not installed into the original project. Both
the YAML and Python guard must be adopted together because broad regex rules in the
old guard would delete the active cost target. An empty exclusion file is rejected
by the candidate guard. These safeguards do not independently validate source data.
