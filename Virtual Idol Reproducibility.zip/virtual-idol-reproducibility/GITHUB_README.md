# Virtual Idol Campaign Valuation: Corrected SBERT–LightGBM Diagnostic

**Status:** Independent corrected exploratory analysis, completed 27 October 2026. **Not** a reproduction of the historical manuscript run.

## Contents
- `run_lightgbm_audit.py`: executable corrected diagnostic.
- `finalize_audit.py`: verification/finalization script.
- `results/`: saved models, metrics, split and CV memberships, predictions, frozen embeddings, feature importance and manifest.
- `supplied_evidence/`: source code/configuration supplied for audit; **not** a complete historical implementation.
- `proposed_guard/`: separately tested candidate feature guard; **not installed** in the historical project.
- `AUDIT_REPORT.md` and `README.md`: original audit findings and execution details.
- `DATA_AVAILABILITY.md`: missing source data and publication restrictions.

## Environment
The completed run recorded Python 3.12.14, numpy 2.3.5, pandas 2.2.3, scikit-learn 1.8.0, lightgbm 4.7.0, torch 2.14.1+cpu, sentence-transformers 6.2.0 and transformers 5.21.0. See `requirements.txt`; install an appropriate CPU Torch build separately.

The frozen encoder was `sentence-transformers/all-MiniLM-L6-v2`, revision `1110a243fdf4706b3f48f1d95db1a4f5529b4d41`.

## Reproduction
Place the authorized original 3,000-row CSV in a private location, verify its SHA-256 against `results/manifest.json`, then run from the repository root:

```bash
python run_lightgbm_audit.py \
  --data /path/to/authorized_original.csv \
  --previous-splits results/split_assignment.csv \
  --out /path/to/new_output \
  --sbert-model sentence-transformers/all-MiniLM-L6-v2 \
  --revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41
```

The command is transcribed from the supplied audit documentation; it has **not been rerun in this packaging session** because the original CSV is absent.

## Findings and interpretation
The saved corrected audit reports all-structured holdout R² = 0.958084, total-cost-only R² = 0.960941, nonfinancial structured R² = 0.000150, and nonfinancial + frozen SBERT R² = 0.000566. Financial predictors account for most of the observed high performance. The frozen SBERT increment is not robustly distinguishable from zero in the reported conditional bootstrap comparison. These are exploratory prediction results, **not** causal pricing or demand-elasticity evidence.

The saved checks report passing holdout and CV metric recomputation, role disjointness and embedding hash verification; those checks were executed in the source audit, not independently rerun during GitHub packaging.

## Before public release
1. Confirm permission to publish derived row-level outputs, embeddings, source metadata and supplied code.
2. Obtain and hash-check the original source CSV, or document restricted access.
3. Rerun the documented environment on a clean machine and compare results.
4. Reconcile every manuscript table and methodological claim against this diagnostic.
5. Add a confirmed license and citation metadata only after ownership and author details are settled.

Do **not** describe this repository as the historical run or as proof of prospective pricing validity.
