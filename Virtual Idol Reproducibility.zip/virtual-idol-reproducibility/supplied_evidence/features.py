"""
Feature preparation utilities for the Virtual Idol Pricing project.

Responsibilities:
- Select the correct target based on task ('regression' or 'classification')
- Remove rows with missing targets
- Drop identifier columns from the feature matrix
- Split features into numeric and categorical lists (bool treated as numeric)
- (Optional) Append SBERT/BERT text embeddings for columns listed in config.data.text_columns
"""

from __future__ import annotations

from typing import Tuple, List, Dict
import pandas as pd


def _get_target_name(cfg: Dict, task: str) -> str:
    if task == "regression":
        return cfg["data"]["target_regression"]
    if task == "classification":
        return cfg["data"]["target_classification"]
    raise ValueError("task must be 'regression' or 'classification'")


def _drop_id_column(X: pd.DataFrame, cfg: Dict) -> pd.DataFrame:
    id_col = cfg["data"].get("id_column")
    if id_col and id_col in X.columns:
        return X.drop(columns=[id_col])
    return X


def _split_num_cat(X: pd.DataFrame) -> Tuple[List[str], List[str]]:
    """
    Return (numeric_columns, categorical_columns).
    - numeric includes int/float/bool
    - categorical = all remaining non-numeric columns
    """
    num_cols = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c]) or pd.api.types.is_bool_dtype(X[c])]
    cat_cols = [c for c in X.columns if c not in num_cols]
    return num_cols, cat_cols


def prepare_features(
    df: pd.DataFrame,
    cfg: Dict,
    task: str
) -> Tuple[pd.DataFrame, pd.Series, List[str], List[str]]:
    """
    Build the feature matrix X and target y for the given task,
    and return lists of numeric and categorical feature names.

    Parameters
    ----------
    df : DataFrame
        Input dataframe after cleaning and leakage guard.
    cfg : dict
        Loaded configuration dict.
    task : str
        'regression' or 'classification'.

    Returns
    -------
    X : DataFrame
        Feature matrix with id_column removed (if present).
    y : Series
        Target vector (float for regression, category for classification).
    num_cols : list[str]
        Numeric feature names.
    cat_cols : list[str]
        Categorical feature names.
    """
    target = _get_target_name(cfg, task)
    if target not in df.columns:
        raise KeyError(f"Target column '{target}' not found in dataframe.")

    # Work on rows that have the target (and keep this filtered frame for embeddings too)
    df2 = df.dropna(subset=[target]).copy()

    # Build X, y
    y = df2[target]
    X = df2.drop(columns=[target])

    # Ensure classification target is categorical dtype
    if task == "classification":
        if not pd.api.types.is_categorical_dtype(y):
            y = y.astype("category")
    else:
        # regression → coerce to float
        y = pd.to_numeric(y, errors="coerce")
        if y.isna().any():
            # If coercion created NaNs, drop those rows consistently in X and y
            keep = ~y.isna()
            X, y = X.loc[keep].copy(), y.loc[keep].astype(float)

    # Remove identifier column from features
    X = _drop_id_column(X, cfg)

    # Split numeric vs categorical (pre-embeddings)
    num_cols, cat_cols = _split_num_cat(X)

    # --- BERT/SBERT text embeddings (optional) ---
    nlp_cfg = cfg.get("nlp", {})
    text_cols = list(cfg.get("data", {}).get("text_columns", []))
    use_bert = bool(nlp_cfg.get("use_sentiment", False)) and str(nlp_cfg.get("engine", "")).lower() in {"bert", "sbert"}

    if use_bert and text_cols:
        # Import lazily so the project runs even if sentence-transformers isn't installed
        from src.nlp.embeddings import TextEmbedder

        emb = TextEmbedder(
            model_name=nlp_cfg.get("model_name", "sentence-transformers/all-MiniLM-L6-v2"),
            device=nlp_cfg.get("device", None),
            batch_size=int(nlp_cfg.get("batch_size", 64)),
            normalize_embeddings=bool(nlp_cfg.get("normalize_embeddings", False)),
        )
        # Use df2 (already filtered for valid target) to keep indices aligned with X/y
        emb_df = emb.encode_df(df2, text_cols)  # shape: (n, embed_dims * len(text_cols))

        # Concatenate embeddings to X (treat them as numeric features)
        X = pd.concat([X, emb_df], axis=1)

        # Drop raw text columns from X (we don't want to pass raw text to the encoder)
        for c in text_cols:
            if c in X.columns:
                X = X.drop(columns=[c], errors="ignore")

        # Update numeric/categorical lists:
        #   - embeddings are numeric, so add them to num_cols
        #   - remove any text columns from cat_cols if they were there
        emb_numeric = [c for c in emb_df.columns if c not in num_cols]
        num_cols = list(num_cols) + emb_numeric
        cat_cols = [c for c in cat_cols if c not in text_cols]

    # Final sanity: ensure we have at least 1 feature
    if len(num_cols) + len(cat_cols) == 0:
        raise ValueError("No features remain after preparation. Check guard rules, drop lists, and text settings.")


    return X, y, num_cols, cat_cols


