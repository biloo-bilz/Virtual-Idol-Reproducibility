"""
LightGBM regression training for the Virtual Idol Pricing project.

Pipeline:
  1) Load raw data from cfg.paths.raw_excel
  2) Clean & leakage-guard (task='regression')
  3) Prepare features (X, y, num_cols, cat_cols)
  4) Create lockbox split + CV folds
  5) Build encoder + LightGBM regressor from cfg
  6) Cross-validate on training split; compute RMSE/MAE/R2/MAPE
  7) Fit final model on all training data; evaluate on lockbox test
  8) Save:
     - outputs/models/regressor_lgbm.pkl  (dict: {'encoder','model','feature_names'})
     - outputs/metrics/regression_cv.json
     - outputs/metrics/regression_lockbox.json
"""

from __future__ import annotations

import json
import os
import logging
from dataclasses import asdict, dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from src.data_io.load import load_raw_from_config
from src.preprocessing.clean import basic_clean
from src.preprocessing.guard import apply_leak_guard
from src.preprocessing.features import prepare_features
from src.preprocessing.split import make_lockbox_and_cv_regression
from src.encoding.categorical import build_encoder_from_config
from src.utils.io_utils import ensure_dir

try:
    import lightgbm as lgb
except ImportError as e:
    raise ImportError(
        "LightGBM is required. Install it with:\n  pip install lightgbm\nor\n  conda install -c conda-forge lightgbm"
    ) from e

try:
    import joblib
except ImportError as e:
    raise ImportError("joblib is required. Install with: pip install joblib") from e


# ------------------------------- metrics ------------------------------------- #

def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def _mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))

def _r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return float(1.0 - (ss_res / (ss_tot + 1e-12)))

def _mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = np.maximum(np.abs(y_true), 1e-12)
    return float(np.mean(np.abs((y_true - y_pred) / denom)) * 100.0)

def _metrics_dict(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    return {
        "rmse": _rmse(y_true, y_pred),
        "mae": _mae(y_true, y_pred),
        "r2": _r2(y_true, y_pred),
        "mape_percent": _mape(y_true, y_pred),
    }


# ------------------------ feature-name sanitization -------------------------- #

import re

def _sanitize_feature_names(names: List[str]) -> List[str]:
    """
    Make names LightGBM-safe by removing JSON-special and non-alnum chars.
    Ensures uniqueness by appending a suffix if needed.
    """
    safe = []
    seen = set()
    for n in names:
        s = re.sub(r"[^A-Za-z0-9_]+", "_", str(n))   # replace bad chars with _
        s = re.sub(r"_+", "_", s).strip("_")         # collapse repeats, trim edges
        if not s:
            s = "f"
        base = s
        i = 1
        while s in seen:
            i += 1
            s = f"{base}_{i}"
        seen.add(s)
        safe.append(s)
    return safe

def _rename_df_columns_safe(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    names = list(df.columns)
    safe = _sanitize_feature_names(names)
    if names != safe:
        df = df.copy()
        df.columns = safe
    return df, safe


# ------------------------------- helpers ------------------------------------- #

def _quantile_bins(y: pd.Series, n_bins: int) -> np.ndarray:
    y = pd.Series(y).reset_index(drop=True)
    if n_bins <= 1:
        raise ValueError("n_bins must be >= 2 for quantile stratification.")
    try:
        cats = pd.qcut(y, q=n_bins, labels=False, duplicates="drop")
        if cats.isna().any() or len(np.unique(cats.dropna())) < max(2, n_bins // 2):
            raise ValueError("degenerate bins")
        return cats.astype(int).to_numpy()
    except Exception:
        ranks = y.rank(method="average").to_numpy()
        ranks = (ranks - ranks.min()) / (ranks.max() - ranks.min() + 1e-12)
        bins = np.floor(ranks * n_bins).astype(int)
        bins[bins == n_bins] = n_bins - 1
        return bins


def _lgbm_regressor_from_cfg(cfg: Dict) -> lgb.LGBMRegressor:
    params = dict(cfg.get("model", {}).get("lgbm_regression", {}))

    # strip any early-stopping keys from constructor (we will pass them to fit())
    for k in list(params.keys()):
        if k.lower() in {"early_stopping_round", "early_stopping_rounds"}:
            params.pop(k, None)

    # sensible defaults
    params.setdefault("n_estimators", 1000)
    params.setdefault("learning_rate", 0.03)
    params.setdefault("num_leaves", 63)
    params.setdefault("subsample", 0.8)
    params.setdefault("colsample_bytree", 0.8)
    params.setdefault("reg_alpha", 0.0)
    params.setdefault("reg_lambda", 0.0)
    params.setdefault("min_child_samples", 20)
    params.setdefault("random_state", cfg.get("random_seed", 42))
    params.setdefault("objective", "rmse")

    return lgb.LGBMRegressor(**params)



@dataclass
class CVResult:
    fold: int
    rmse: float
    mae: float
    r2: float
    mape_percent: float


# ------------------------------- core train ---------------------------------- #

def _cross_validate_train(
    cfg: Dict,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    outer_cv,
    enc_num_cols: List[str],
    enc_cat_cols: List[str],
    logger: logging.Logger,
) -> Tuple[List[CVResult], lgb.LGBMRegressor, object, List[str]]:
    encoder = build_encoder_from_config(cfg, enc_num_cols, enc_cat_cols)
    base_model = _lgbm_regressor_from_cfg(cfg)

    # ES rounds from config if present (else 100)
    # AFTER (correct: nested under lgbm_regression)
    es_rounds = int(cfg.get("model", {}).get("lgbm_regression", {}).get("early_stopping_rounds", 100))

    is_stratified = outer_cv.__class__.__name__.lower().startswith("stratified")
    y_strat = None
    if is_stratified:
        n_bins = int(cfg["split"].get("regression_stratify_bins", 5))
        y_strat = _quantile_bins(y_train, n_bins)

    cv_rows: List[CVResult] = []
    safe_names: List[str] = []

    for fold, (tr_idx, val_idx) in enumerate(outer_cv.split(X_train, y_strat if is_stratified else None), start=1):
        X_tr, X_val = X_train.iloc[tr_idx], X_train.iloc[val_idx]
        y_tr, y_val = y_train.iloc[tr_idx], y_train.iloc[val_idx]

        # fresh model per fold
        model = _lgbm_regressor_from_cfg(cfg)

        # Fit encoder on TRAIN only; transform train/val
        X_tr_enc = encoder.fit_transform(X_tr)
        X_val_enc = encoder.transform(X_val)

        # sanitize names
        X_tr_enc, safe_names = _rename_df_columns_safe(X_tr_enc)
        X_val_enc, _ = _rename_df_columns_safe(X_val_enc)

        # Fit with explicit eval_set for early stopping
        # Fit with explicit eval_set and ES via callback (compatible with older LightGBM)
        model.fit(
            X_tr_enc, y_tr,
            eval_set=[(X_val_enc, y_val)],
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(es_rounds, verbose=False)],
        )

        y_pred = model.predict(X_val_enc)
        m = _metrics_dict(y_val.to_numpy(dtype=float), y_pred.astype(float))
        cv_rows.append(CVResult(fold=fold, **m))

        logger.info("[reg.cv] fold=%d  rmse=%.4f  mae=%.4f  r2=%.4f  mape=%.2f%%",
                    fold, m["rmse"], m["mae"], m["r2"], m["mape_percent"])

    # Refit final model on ALL training data with best_iteration_ from last fold (fallback to n_estimators)
    final_model = _lgbm_regressor_from_cfg(cfg)
    X_all_enc = encoder.fit_transform(X_train)
    X_all_enc, safe_names = _rename_df_columns_safe(X_all_enc)

    # If the last fold had a best_iteration_, reuse as n_estimators for refit
    best_iter = getattr(model, "best_iteration_", None)  # from last fold
    if isinstance(best_iter, int) and best_iter > 0:
        final_model.set_params(n_estimators=best_iter)

    final_model.fit(X_all_enc, y_train)

    return cv_rows, final_model, encoder, safe_names


def run_lgbm_regressor(cfg: Dict) -> Dict:
    """
    Full training entry point for the regression task.
    Returns a dict with saved paths and headline metrics.
    """
    log = logging.getLogger(__name__)

    # 1) Load + clean + guard
    df = load_raw_from_config(cfg)
    log.info("[reg] raw shape: %s", df.shape)
    df = basic_clean(df, cfg["data"]["percent_fields"])
    log.info("[reg] after basic_clean: %s", df.shape)
    df = apply_leak_guard(df, cfg, task="regression")
    log.info("[reg] after leak_guard: %s", df.shape)

    # 2) Build features
    X, y, num_cols, cat_cols = prepare_features(df, cfg, task="regression")
    log.info("[reg] X:%s y:%d  num=%d  cat=%d", X.shape, len(y), len(num_cols), len(cat_cols))

    # 3) Lockbox + CV
    lock = make_lockbox_and_cv_regression(
        X, y,
        lockbox_size=cfg["split"]["lockbox_size"],
        n_outer_folds=cfg["split"]["n_outer_folds"],
        n_inner_folds=cfg["split"]["n_inner_folds"],
        regression_stratify_bins=cfg["split"]["regression_stratify_bins"],
        shuffle_before_split=cfg["split"]["shuffle_before_split"],
        random_state=cfg.get("random_seed", 42),
    )
    log.info("[reg] lockbox: X_train=%s X_test=%s y_train=%d y_test=%d",
             lock.X_train.shape, lock.X_test.shape, len(lock.y_train), len(lock.y_test))

    # 4) Cross-validate on training split
    cv_rows, final_model, final_encoder, safe_names = _cross_validate_train(
        cfg,
        lock.X_train, lock.y_train,
        lock.outer_cv,
        num_cols, cat_cols,
        log,
    )

    # 5) Evaluate on lockbox
    X_test_enc = final_encoder.transform(lock.X_test)
    X_test_enc, _ = _rename_df_columns_safe(X_test_enc)
    y_test_pred = final_model.predict(X_test_enc)
    lock_metrics = _metrics_dict(lock.y_test.to_numpy(dtype=float), y_test_pred.astype(float))
    log.info("[reg.lockbox] rmse=%.4f  mae=%.4f  r2=%.4f  mape=%.2f%%",
             lock_metrics["rmse"], lock_metrics["mae"], lock_metrics["r2"], lock_metrics["mape_percent"])

    # 6) Save model (encoder + model) and metrics
    # 6) Save model (encoder + model) and metrics
    models_dir = cfg["paths"]["models_dir"]
    metrics_dir = cfg["paths"]["metrics_dir"]
    ensure_dir(models_dir)
    ensure_dir(metrics_dir)

    # Bundle encoder + model + feature names into ONE artifact
    model_artifact = {
        "encoder": final_encoder,
        "model": final_model,
        "feature_names": list(safe_names),
    }
    model_path = os.path.join(models_dir, "regressor_lgbm.pkl")
    joblib.dump(model_artifact, model_path)

    # ---- Build CV metrics dict ----
    def _row_to_dict(r):
        try:
            return asdict(r)  # dataclass
        except Exception:
            return dict(r)

    cv_dict_rows = [_row_to_dict(r) for r in cv_rows]
    cv_mean = {
        "rmse": float(np.mean([d["rmse"] for d in cv_dict_rows])),
        "mae": float(np.mean([d["mae"] for d in cv_dict_rows])),
        "r2": float(np.mean([d["r2"] for d in cv_dict_rows])),
        "mape_percent": float(np.mean([d["mape_percent"] for d in cv_dict_rows])),
    }
    cv_std = {
        "rmse": float(np.std([d["rmse"] for d in cv_dict_rows], ddof=1)) if len(cv_dict_rows) > 1 else 0.0,
        "mae": float(np.std([d["mae"] for d in cv_dict_rows], ddof=1)) if len(cv_dict_rows) > 1 else 0.0,
        "r2": float(np.std([d["r2"] for d in cv_dict_rows], ddof=1))  if len(cv_dict_rows) > 1 else 0.0,
        "mape_percent": float(np.std([d["mape_percent"] for d in cv_dict_rows], ddof=1)) if len(cv_dict_rows) > 1 else 0.0,
    }

    cv_metrics = {
        "folds": cv_dict_rows,
        "mean": cv_mean,
        "std": cv_std,
    }

    cv_path = os.path.join(metrics_dir, "regression_cv.json")
    with open(cv_path, "w", encoding="utf-8") as f:
        json.dump(cv_metrics, f, indent=2)

    # Lockbox metrics (use the variable name you computed above: lock_metrics)
    lockbox_path = os.path.join(metrics_dir, "regression_lockbox.json")
    with open(lockbox_path, "w", encoding="utf-8") as f:
        json.dump(lock_metrics, f, indent=2)

    # Return paths to caller (main.py)
    return {
        "model_path": os.path.abspath(model_path),
        "cv_metrics_path": os.path.abspath(cv_path),
        "lockbox_metrics_path": os.path.abspath(lockbox_path),
        "lockbox_metrics": lock_metrics,
        "cv_mean": cv_mean,
    }
